let mySingleton = (function () {
	let instance;
	function init() {
		return {
			sendMe: async function (method) {
				if(method == 'GET') {
					let xhr = new XMLHttpRequest();
					xhr.open(method, "https://reqres.in/api/products/3", true);
					xhr.onload = function() {
						let idtest = JSON.parse(xhr.responseText).data.id;
    					console.log('ID даного персонажа - ' + idtest);
					};
					xhr.send();
		

					let response = await fetch("https://reqres.in/api/users?page=2");
					console.log(response);
					let testemail = await response.json();
					console.log('email первого персонажа в списке: '+testemail.data[0].email);
				}
				
				if(method == 'POST') {
		
					let user = {
						name: "mmmorpheus",
						job: "leader"
					};
					let response2 = await fetch('https://reqres.in/api/users', {
						method: method,
						headers: {
							'Content-Type': 'application/json;charset=utf-8'
						},
						body: JSON.stringify(user)
					});
					let result = await response2.json();
					console.log('Post запрос, имя персонажа: '+result.name);
				}
			}
		}
	}
	return {
		getInstance: function() {
			if (!instance) {
				instance = init();
			}
			return instance;
		}
	}
}) ();

let singleA = mySingleton.getInstance();

function doDelivery(method) {
	singleA.sendMe(method);
}

function decorator(wrapped) {
	return function() {
		const result = wrapped.apply(this,arguments);
		return result;
	}
}
 try {
	decorator(doDelivery)('GET');
	decorator(doDelivery)('POST');
	wrapped();  //это я добавил, чтобы посмотреть как работает try catch
} catch(e) {
	alert(':(');
}